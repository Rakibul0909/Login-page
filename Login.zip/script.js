function validateLogin(event) {
    event.preventDefault();  // Prevent the form from submitting

    // Get the input values
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Check if the username and password are correct
    if (username === "Rakibul" && password === "8888") {
        document.getElementById("message").textContent = "Login successful!";
        document.getElementById("message").style.color = "green";
    } else {
        document.getElementById("message").textContent = "Invalid Username or Password!";
        document.getElementById("message").style.color = "red";
    }
}